#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#include <unistd.h>
#include <stdlib.h>

#include <sys/wait.h>
#include <sys/types.h>
#include "display_functions.h"


#define ALPHABET_START 97

void add_letter(wchar_t* alphabet_tested_letters, wchar_t letter)
{
	/*
	Add a letter given in parameter to the alphabet of known letters at the right alphabetic position.
	*/
	
	int pos_letter;
	
	pos_letter = ((int)letter - ALPHABET_START);
	alphabet_tested_letters[pos_letter] = letter;
	
}

int in_the_word(wchar_t* random_word, wchar_t letter)
{
	/*
	Return 0 if the letter isn't in the word, 1 otherwise
	*/
	int i = 0, nbr = 0;
		
	while (random_word[i] != L'\0')
	{
		if (random_word[i] == letter)
		{
			return 1;
		}
		i++ ;
	}
	return 0;

}

void display_word(wchar_t* mot, wchar_t* alphabet_tested_letters)
{
	/*
		Display the word, but only reveal the letters the user already knows.
		for each letter in the word the corresponding character in alphabet_tested_letters is displaying, the letter itself or #
					
	*/
	int i, pos_alphabet;
	
	i = 0;
	wprintf(L"\n");
	while (mot[i] != L'\0')
	{
		pos_alphabet = ((int)(mot[i] - ALPHABET_START));
		
		// for each letter in the word, if the letter is the present in the alphabet of tested letters she is displayed, otherwise # is displayed.
		wprintf(L"%c", alphabet_tested_letters[pos_alphabet]); 
		i++ ;
	}
	wprintf(L"\n");
}


void ask_guess_count(int* guess_count)
{
	/* 
	ask to the user how many ask he wants to have.
	*/
	
	wprintf(L"How many guess would you like? : ");
	wscanf(L"%d",guess_count);
	getwchar();
	
}

void clear_screen()
{
	pid_t pid;
	pid = fork();
	wprintf(L"pid : %d\n",pid);
			
	if (pid == -1) 
	{
    	perror("fork\n");
    	exit(EXIT_FAILURE);
	}
	if (pid == 0)
	{
		execlp("clear", "clear", NULL);
		perror("fils\n");
				
		exit(0);
	}

	else
	{
				
		wait(NULL);
		
	}

	

}

