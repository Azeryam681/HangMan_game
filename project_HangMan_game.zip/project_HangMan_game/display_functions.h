#ifndef DEF_display_functions

#define DEF_display_functions


#define ALPHABET_START 97

#include <stdio.h>
#include <wchar.h>
#include <locale.h>



void add_letter(wchar_t* alphabet_tested_letters, wchar_t letter);

int in_the_word(wchar_t* random_word, wchar_t letter);

void display_word(wchar_t* mot, wchar_t* alphabet_tested_letters);

void ask_guess_count(int* guess_count);


#endif
