
#include <stdio.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>

#include "language_functions.h"

void choose_language(languages* language)
{
	wchar_t l[TAILLE_MAX] ;
	wprintf(L"Veuillez insérer la language dans laquelle vous souhaitez jouer (English, French, Polish)\n");
	wscanf(L"%ls", l);
	getwchar();
	
	

	if (wcscmp(l, L"French") == 0)
	{
		*language = FRENCH;
		
	}
		
	else if (wcscmp(l, L"English") == 0)
	{
		*language = ENGLISH;
		
	}
	
	else if (wcscmp(l, L"Polish") == 0)
	{
		*language = POLISH;
		
	}	
}


