#ifndef DEF_language_functions

#define DEF_language_functions

#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

#define TAILLE_MAX 100


enum languages
{
	ENGLISH,
	FRENCH,
	POLISH
};
typedef enum languages languages;


void choose_language(languages* language);



#endif
