#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <wchar.h>
#include <locale.h>



#include "word_processing_functions.h"
#include "display_functions.h"
#include "language_functions.h"
#include "unistd.h"






int main()
{
	
	setlocale(LC_ALL, "");
	FILE* file;
	int guess_count, i, discovered, iteration_count, word_size, file_closing_report, main_loop_continue;
	long nbr_lines, word_position;

	wchar_t random_word[100];
	wchar_t* user_proposed_word = (wchar_t*)malloc(sizeof(wchar_t) * (20));
	
	//wchar_t alphabet[27] = L"##########################";  // l'alphabet des letters qui ont été utilisés 	initialement l'alphabet contient 26 fois #
	wchar_t alphabet[27];
	wchar_t letter;
	
	languages language;
	
	main_loop_continue = 1;
	
	while(main_loop_continue)
	{
		set_alphabet(alphabet);
		
		choose_language(&language);
		
		word_position = 0;
		i = 0;
		discovered = 0;
		iteration_count = 0; // nombre de tour qui ont été joué par le joueur
		
		ask_guess_count(&guess_count);
		
		
		
		if (language == FRENCH)
			
			file = open_file("words_lists/french_words.txt");
		else if(language == ENGLISH)
			file = open_file("words_lists/english_words.txt");	
		
		else if(language == POLISH)
			file = open_file("words_lists/polish_words.txt");	
		nbr_lines = count_lines(file);
		
		
		
		choose_word(file,random_word, &word_size, &word_position);
		
		
		wprintf(L"the word's length: %d\n",word_size);
		wprintf(L"the word :%ls\n",random_word);
		wprintf(L"le mot est en position : %d\n",word_position);
		
		initialise_word(word_size, user_proposed_word);
		non_accented_letters(random_word); // on transforme le mot en mot non accentué
		
		
		
		wprintf(L"alphabet :%ls\n",alphabet);
		
		while((i < guess_count) && (!discovered))
		{
					// Dérouler d'un essai
			/*
			un essai comprend :
			-- l'affichage du numéro d'essai
			-- l'affichage du nombre d'essai restant
			-- l'affichage des letters qui ont été utilisés
			-- l'affichage du mot avec ses letters découvertes
			
			-- la saisi d'une letter 
			-- si la letter saisie est 0 saisi d'un mot
			*/
			
			/*
			fflush(stdout);
			
			execl("/bin/clear", "clear", NULL);
			
			fflush(stdout);
			*/
			
			iteration_count++ ;	
			
			wprintf(L"####################### TRY: %d #######################\n",iteration_count );
			
			wprintf(L"\n\n");
			wprintf(L"There is %d guess left :\n",guess_count - i);
			wprintf(L"alphabet of tested letters :%ls\n",alphabet);
			
			display_word(random_word, alphabet);
			
			wprintf(L"Please enter a letter :\n");
			wscanf(L"%c",&letter);
			
			wprintf(L"user proposed word : %ls\n",user_proposed_word);
			
			getwchar();
			
			if(letter == (L'0'))
			{
				wprintf(L"0 as been entered.\n");
				user_proposed_word = typing_word(user_proposed_word);
				wprintf(L"\nthe word that you have entered : %ls\n",user_proposed_word);
				i++ ; 
			}
			
			
			else
			{
				if (in_the_word(random_word, letter) == 1)
					wprintf(L"the letter : %c is in the word.\n", letter);
				else
				{
					wprintf(L"the letter : %c isn't in the word.\n", letter);
					i++ ;
				}
			}	
			
					// fin dérouler de l'essai
					
					// traitement des données saisis
			
			add_letter(alphabet, letter); // ajouter la letter dans l'alphabet des letters découverte si cette letter était 0 rien ne sera ajouté
			
			
			display_word(random_word, alphabet); 
			
					// fin traitement des données saisis
					
					// arrêt de la boucle si le mot est découvert
			discovered = is_correct(random_word, user_proposed_word, alphabet);
			if (discovered)
				wprintf(L"The word is correct, congrats ");
			
			
			
			wprintf(L"########################################################\n\n\n\n");
			
			
		}

		
		
		
		
		file_closing_report = close_file(file);
		
		wprintf(L"file_closing_report du file : %d\n",file_closing_report);
		
		// Demander au joueur s'il veut main_loop_continue, terminer le programme s'il ne le souhaite pas
		wprintf(L"Do you to play an another game? 1 for yes, 0 for no\n");
		wscanf(L"%d",&main_loop_continue);
		getwchar();
		
	}

}

