#include <stdio.h>
#include <wchar.h>
#include <locale.h>
#include <ncurses.h>

#define size_MAX 100
#include "word_processing_functions.h"



void display_menu(FILE* menu_file, int cursor_position)
{
	int i, nbr_lines;
	i = 0;
	wchar_t line[size_MAX];
	
	nbr_lines = count_lines(menu_file);
	while (i++ < nbr_lines)
	{
		fgetws(line, size_MAX, menu_file);
		wprintf(L"%ls",line);
		if (i == cursor_position)
		{
			wprintf(L"  #");
		}
	}
	
}



void interaction_menu(FILE* menu_file, int cursor_position)
{
	wchar_t c ;
	
	c = getch();
	wprintf(L"le caractère tapé : %lc\n",c);
}

int main()
{
	FILE* file = open_file("menu.txt");
	display_menu(file, 2);
	interaction_menu(file, 1);
}
