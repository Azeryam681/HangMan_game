#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>

#include "word_processing_functions.h"

#define ALPHABET_START 97

#define size_MAX 100

FILE* open_file(const char* name_file)
{
	/*
	Open the file whose name is given as a parameter.
	Return a pointer to the opened file.
	*/
	
	FILE* file;
	
	file = fopen(name_file,"r");
	
	return file;

} 


int close_file(FILE* file)
{
	/*
	Close the file whose is giving in parameter
	*/
	
	return fclose(file);
}


long count_lines(FILE* file)
{
	/*
	Count the number on line of the file giving in parameter

	The file is read character by character until the WEOF character is encountered  EOF isn't used because the file may contain accented characters and therefore requires wide characters (wchar_t).
	The number of lines is retourned by the function.
	*/
	
	long nbr_lines;
	wint_t c;
	nbr_lines = 0;
	if (file != NULL)
	{
		rewind(file); // replace the counter to the file begin, a precaution
		do 
		{
		
		c = fgetwc(file); // read a character in file file.
		
		if (c == (L'\n'))  
			nbr_lines++ ;
		
		
		}while(c != WEOF);
		rewind(file); // replace the counter to the file begin, a precaution 
		return nbr_lines;
	}
	
	// the file hasn't been opened correctly.
	return (-1);
	
}

void word_lenght(wchar_t* word, int* word_size)
{
	/*
	Determine the lenght of the word given as a parameter on put on the pointer word_size
	*/
	int i = 0;
	
	while(word[i] != L'\n')
	{
		i++ ;
	}
	word[i] = L'\0';
	*word_size = i;
}


void choose_word(FILE* file, wchar_t* word, int* word_size, long* word_position)
{
	
	long nbr_lines; 
	int i;
	
	srand(time(NULL));
	
	nbr_lines = count_lines(file);	
	
	*word_position = (rand() % (nbr_lines  + 1)); // choose a random line in the file.
	
	rewind(file); // replace the counter to the file begin, a precaution 
	
	for(i = 0; i <= (*word_position); i++) // read every lines until the right line isn't encountered
	{
		fgetws(word, size_MAX,file);  // put the word in the character chain "word".
		
	}
	
	
	
	word_lenght(word, word_size);
	rewind(file); // replace the counter to the file begin, a precaution  
}





void non_accented_letters(wchar_t* word)
{
	/* 
	Replace the accented letters in the word by the non-accented equivalent
	*/
	
	int i;
	i = 0;
	
	
	
	while(word[i] != L'\0')
	{
		switch(word[i])
		{
		
		// e accented
		case(L'é'):
		
		case(L'ę'):
		
		case(L'è'):
		
		case(L'ë'):
		
		case(L'ê'):
			word[i] = L'e';
			break;
			
			
		// n accented
		case(L'ń'):
			word[i] = L'n';
			break;
			
			
		// a accented
		case(L'ą'):
		
		case(L'â'):
		
		case(L'à'):
				
		case(L'ä'):
			word[i] = L'a';
			break;
			
		// i accented
		case(L'î'):
		
		case(L'ï'):
			word[i] = L'i';
			break;
			
			
		// o accented
		case(L'ô'):
		
		case(L'ó'):
			word[i] = L'o';
		
		case(L'ö'):
			word[i] = L'o';
			break;
			
			
		// u accented
		case(L'û'):
		
		case(L'ü'):
		
		case(L'ù'):
			word[i] = L'u';
			break;
		
		
		// y accented
		case(L'ÿ'):
			word[i] = L'y';
			break;
			
			
		// c accented
		case(L'ç'):
		
		case(L'ć'):
		
			word[i] = L'c';
			break;
			
		case(L'ł'):
			word[i] = L'l';
			break;
			
		// s accented
		case(L'ś'):
			word[i] = L's';
			break;
		
		
		// z accented 
		case(L'ż'):
		
		case(L'ź'):
			word[i] = L'z';
			break;
		}
		
		i++ ;
	
	}

}

wchar_t* typing_word(wchar_t* word)
{
	
	wprintf(L"Type your word : ");
	wscanf(L"%ls",word);
	printf("\n");
	getwchar();
	return word;
}


int is_correct(wchar_t* random_word, wchar_t* user_proposed_word, wchar_t* alphabet_tested_letters)
{
	
	int i = 1, condition, pos_alphabet;
	
	pos_alphabet = ((int)(random_word[0] - ALPHABET_START));
	condition = ((alphabet_tested_letters[pos_alphabet] != L'#') || (user_proposed_word[0] == random_word[0]));
	
	// condition vrai tq la lettre i du word aleatoire est présente dans les lettres decouverte ou égale a la lettre i du word tapée
	// the condition is true while every letter i in the word is in the alphabet of tested letters or the i of the user proposed word
	while((random_word[i] != L'\0') && condition)
	{
		pos_alphabet = ((int)(random_word[i] - ALPHABET_START));
		condition = (alphabet_tested_letters[pos_alphabet] != L'#') || (user_proposed_word[i] == random_word[i]);
		i++;
	}
	return condition;
	
	
}



void initialise_word(int size, wchar_t* word)
{
	
	int i;
	for(i = 0;i < size ;i++)
	{
		word[i] = L'#';
	} 
	word[i] = '\0';
	
}

void set_alphabet(wchar_t* alphabet_tested_letters)
{
	/*
	fill every cell of the alphabet with a #
	*/
	
	for(int i = 0; i < 26; i++)
	{
		alphabet_tested_letters[i] = L'#';
	}
	alphabet_tested_letters[26] = L'\0';
}


