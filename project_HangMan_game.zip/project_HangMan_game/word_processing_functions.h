#ifndef DEF_word_processing_functions

#define DEF_word_processing_functions

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>


FILE* open_file(const char* name_file);

int close_file(FILE* file);

long count_lines(FILE* file);

void word_lenght(wchar_t* word, int* word_size);

void choose_word(FILE* file, wchar_t* word, int* word_size, long* word_position);

void non_accented_letters(wchar_t* word);

wchar_t* typing_word(wchar_t* word);

int is_correct(wchar_t* random_word, wchar_t* user_proposed_word, wchar_t* alphabet_tested_letters);

void initialise_word(int size, wchar_t* word);

void set_alphabet(wchar_t* alphabet_tested_letters);

#endif
