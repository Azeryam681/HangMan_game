#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <wchar.h>
#include <locale.h>



#include "fonction_fichier_mots.h"
#include "fonction_affichage.h"



void est_decouvert(wchar_t mot_aleatoire[100], wchar_t proposition, int* decouvert, wchar_t alphabet[27])
{
	
	*decouvert = est_correct(mot_aleatoire, proposition, alphabet);
	if (*decouvert)
		wprintf(L"Vous avez trouvé le mot, bravo ");
	else
		wprintf(L"La proposition que vous avez faites est fausse\n");
}

void derouler_essai(int* nombre_essai, int* decouvert, wchar_t alphabet[27], wchar_t lettre, wchar_t mot_aleatoire[100], wchar_t proposition)

{
	wprintf(L"####################### ESSAIS: %d #######################\n",i );
		
	wprintf(L"\n\n");
	wprintf(L"il vous reste %d essais\n",*nombre_essai - i);
	wprintf(L"alphabet des lettres utilisés :%ls\n",alphabet);
		
	affichage_mot(mot_aleatoire, alphabet);
		
	wprintf(L"Saisir une lettre :\n");
	wscanf(L"%c",&lettre);
		
	wprintf(L"La proposition : %ls\n",proposition);
		
	getwchar();
	if(lettre == (L'0'))
	{
		wprintf(L"la lettre saisi était 0\n");
		proposition = ecrire_mot(proposition);
		wprintf(L"\nle mot que vous avez écrit : %ls\n",proposition); 
	}	
		
	ajouter_lettre(alphabet, lettre);
		
	affichage_mot(mot_aleatoire, alphabet);
		
		
	*decouvert = est_correct(mot_aleatoire, proposition, alphabet);
	est_decouvert(mot_aleatoire, proposition, decouvert, alphabet);
	wprintf(L" est_correct  %d\n",est_correct(mot_aleatoire, proposition, alphabet));
		
	wprintf(L"########################################################\n\n\n\n");
		
	i++ ;
}

