#include <stdio.h>
#include <wchar.h>
#include <locale.h>

#include "fonction_affichage.h"

#define DEBUT_ALPHABET 97

void ajouter_lettre(wchar_t* alphabet, wchar_t lettre)
{
	/*
	Fonction qui 
	ajoute une lettre donnée en paramètre a un alphabet de lettre, en l'ajoutant a la position alphabétique de la lettre
	*/
	
	int pos_lettre;
	
	pos_lettre = ((int)lettre - DEBUT_ALPHABET);
	alphabet[pos_lettre] = lettre;
	
}

int appartient_mot(wchar_t* mot_aleatoire, wchar_t lettre)
{
	/*
	Fonction qui renvoi 0 si la lettre n'est pas dans le mot 1 sinon
	*/
	int i = 0, nbr = 0;
		
	while (mot_aleatoire[i] != L'\0')
	{
		wprintf(L"la lettre du mot aléatoire : %c\n", mot_aleatoire[i]);
		if (mot_aleatoire[i] == lettre)
		{
			return 1;
		}
	i++ ;
	}
	return 0;

}

void affichage_mot(wchar_t* mot, wchar_t* alphabet)
{
	/*
		Fonction qui affiche le mot que le joueur cherche a trouver
		Pour cela pour chaque lettre du mot réel on affiche la lettre correspondante dans l'alphabet des lettres découvertes donc la lettre ou #			
	*/
	int i, pos_alphabet;
	
	i = 0;
	wprintf(L"\n");
	while (mot[i] != L'\0')
	{
		pos_alphabet = ((int)(mot[i] - DEBUT_ALPHABET));
		
		wprintf(L"%c", alphabet[pos_alphabet]); // si la lettre est présente dans l'alphabet des lettres connus alors elle est afficher, sinon # est affiché 
		i++ ;
	}
	wprintf(L"\n");
}


void demander_essai(int* nombre_essai)
{
	/* 
	Fonction qui demande à l'utilisateur de saisir un nombre d'essai donner par adresse en paramètre
	*/
	
	wprintf(L"combien voulez vous d'essais : ");
	wscanf(L"%d",nombre_essai);
	getwchar();
	
}




