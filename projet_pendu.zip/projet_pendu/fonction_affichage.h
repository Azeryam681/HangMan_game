#ifndef DEF_fonction_affichage

#define DEF_fontion_affichage


#define DEBUT_ALPHABET 97

#include <stdio.h>
#include <wchar.h>
#include <locale.h>



void ajouter_lettre(wchar_t* alphabet, wchar_t lettre);

void affichage_mot(wchar_t* mot, wchar_t* alphabet);

int appartient_mot(wchar_t* mot_aleatoire, wchar_t lettre);

void demander_essai(int* nombre_essai);


#endif
