#include <stdio.h>

void afficher_menu()
{
	printf("################  MENU ################\n");
	printf("Veuillez saisir :\n");

}
