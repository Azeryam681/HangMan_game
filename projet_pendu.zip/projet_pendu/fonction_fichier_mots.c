#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>

#include "fonction_fichier_mots.h"
#define DEBUT_ALPHABET 97

#define TAILLE_MAX 100

FILE* ouvrir_fichier(const char* nom_fichier)
{
	/*
	Fonction qui ouvre le fichier dont le nom est donnée sous forme de chaîne de caractères en paramètre et renvoie un pointeur sur le fichier ouvert
	*/
	
	FILE* fichier;
	
	fichier = fopen(nom_fichier,"r");
	
	return fichier;

} 


int fermer_fichier(FILE* fichier)
{
	/*
	Fonction qui ferme le fichier donné en paramètre
	*/
	
	return fclose(fichier);
}


long compter_ligne(FILE* fichier)
{
	/*
	Fonction qui compte le nombre de ligne du fichier donné en paramètre
	pour cela le fichier est lu caractère par caractère jusqu'à rencontré le caractère de fin de fin WEOF ( non EOF car le fichier contient des lettres accentués donc w_char
	renvoie le nombre de ligne
	*/
	
	long nbr_ligne;
	wint_t c;
	nbr_ligne = 0;
	if (fichier != NULL)
	{
		rewind(fichier); // replacer le curseur au début du fichier, une précaution 
		do 
		{
		
		c = fgetwc(fichier);
		
		if (c == (L'\n'))  //
			nbr_ligne++ ;
		
		
		}while(c != WEOF);
		rewind(fichier); // replacer le curseur au début du fichier, une précaution 
		return nbr_ligne;
	}
	return (-1);
	
}

void determiner_taille_mot(wchar_t* mot, int* taille_mot)
{
	int i = 0;
	
	while(mot[i] != L'\n')
	{
		i++ ;
	}
	mot[i] = L'\0';
	*taille_mot = i;
}


void choisir_mot(FILE* fichier, wchar_t* mot, int* taille_mot, long* position_mot)
{
	
	long nbr_ligne; // position_mot est la ligne à laquelle le mot choisi aléatoirement se trouve
	int i;
	
	
	srand(time(NULL));
		
	nbr_ligne = compter_ligne(fichier);
	*position_mot = (rand() % (nbr_ligne  + 1));
	
	rewind(fichier); // replacer le curseur au début du fichier, une précaution  
	
	for(i = 0; i <= (*position_mot); i++) // aller lire les lignes tant que la bonne ligne n'est pas atteinte
	{
		fgetws(mot, TAILLE_MAX,fichier);  
		
	}
	// lorsque la boucle s'arrête nous avons lu le bon mot dans mot
	
	// connaître la taille du mot
	determiner_taille_mot(mot, taille_mot);
	rewind(fichier); // replacer le curseur au début du fichier, une précaution 
}





void non_accentue(wchar_t* mot)
{
	/* 
	Fonction qui remplace le dans le mot les lettres accentués par leur équivalent non accentués
	*/
	
	int i;
	i = 0;
	
	
	
	while(mot[i] != L'\0')
	{
		switch(mot[i])
		{
		
		// les e accentués
		case(L'é'):
		
		case(L'ę'):
		
		case(L'è'):
		
		case(L'ë'):
		
		case(L'ê'):
			mot[i] = L'e';
			break;
			
			
		// les n accentués
		case(L'ń'):
			mot[i] = L'n';
			break;
			
			
		// les a accentués
		case(L'ą'):
		
		case(L'â'):
		
		case(L'à'):
				
		case(L'ä'):
			mot[i] = L'a';
			break;
			
		// les i accentués
		case(L'î'):
		
		case(L'ï'):
			mot[i] = L'i';
			break;
			
			
		// les o accentués
		case(L'ô'):
		
		case(L'ó'):
			mot[i] = L'o';
		
		case(L'ö'):
			mot[i] = L'o';
			break;
			
			
		// les u accentués
		case(L'û'):
		
		case(L'ü'):
		
		case(L'ù'):
			mot[i] = L'u';
			break;
		
		
		// les y accentués
		case(L'ÿ'):
			mot[i] = L'y';
			break;
			
			
		// les c accentués
		case(L'ç'):
		
		case(L'ć'):
		
			mot[i] = L'c';
			break;
			
		case(L'ł'):
			mot[i] = L'l';
			break;
			
		// les s accentués
		case(L'ś'):
			mot[i] = L's';
			break;
		
		
		// les z accentués 
		case(L'ż'):
		
		case(L'ź'):
			mot[i] = L'z';
			break;
		}
		
		i++ ;
	
	}

}

wchar_t* ecrire_mot(wchar_t* mot)
{
	
	wprintf(L"Saisir votre mot : ");
	wscanf(L"%ls",mot);
	printf("\n");
	getwchar();
	return mot;
}


int est_correct(wchar_t* mot_aleatoire, wchar_t* proposition, wchar_t* alphabet)
{
	// on peut mettre les deux mots dans les deux sens
	int i = 1, condition, pos_alphabet;
	
	pos_alphabet = ((int)(mot_aleatoire[0] - DEBUT_ALPHABET));
	condition = ((alphabet[pos_alphabet] != L'#') || (proposition[0] == mot_aleatoire[0]));
	
	// condition vrai tq la lettre i du mot aleatoire est présente dans les lettres decouverte ou égale a la lettre i du mot tapée
	
	while((mot_aleatoire[i] != L'\0') && condition)
	{
		pos_alphabet = ((int)(mot_aleatoire[i] - DEBUT_ALPHABET));
		condition = (alphabet[pos_alphabet] != L'#') || (proposition[i] == mot_aleatoire[i]);
		i++;
	}
	return condition;
	
	
}



void initialiser_mot(int taille, wchar_t* mot)
{
	
	int i;
	for(i = 0;i < taille ;i++)
	{
		mot[i] = L'#';
	} 
	mot[i] = '\0';
	
}

void alphabet_vide(wchar_t* alphabet)
{
	for(int i = 0; i < 26; i++)
	{
		alphabet[i] = L'#';
	}
	alphabet[26] = L'\0';
}



