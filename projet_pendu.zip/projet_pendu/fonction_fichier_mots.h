#ifndef DEF_fonction_fichier_mots

#define DEF_fontion_fichier_mots

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>


FILE* ouvrir_fichier(const char* nom_fichier);

int fermer_fichier(FILE* fichier);

long compter_ligne(FILE* fichier);

void choisir_mot(FILE* fichier, wchar_t* mot, int* taille_mot, long* position_mot);

void non_accentue(wchar_t* mot);

void determiner_taille_mot(wchar_t* mot, int* taille_mot);

wchar_t* ecrire_mot(wchar_t* mot);

int est_correct(wchar_t* mot_aleatoire, wchar_t* proposition, wchar_t* alphabet);

void initialiser_mot(int taille, wchar_t* mot);

void alphabet_vide(wchar_t* alphabet);

#endif
