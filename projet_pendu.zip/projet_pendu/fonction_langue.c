#include <stdio.h>
#include <string.h>

#include <wchar.h>
#include <locale.h>

#include "fonction_langue.h"

#define TAILLE_MAX 100

void choisir_langue(langues* langue)
{
	wchar_t l[TAILLE_MAX] ;
	wprintf(L"Veuillez insérer la langue dans laquelle vous souhaitez jouer (English, French, Polish)\n");
	wscanf(L"%ls", l);
	getwchar();
	
	

	if (wcscmp(l, L"French") == 0)
	{
		*langue = FRENCH;
		
	}
		
	else if (wcscmp(l, L"English") == 0)
	{
		*langue = ENGLISH;
		
	}
	
	else if (wcscmp(l, L"Polish") == 0)
	{
		*langue = POLISH;
		
	}	
}




