#ifndef DEF_fonction_langue

#define fonction_langue

#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <locale.h>

#define TAILLE_MAX 100


enum langues
{
	ENGLISH,
	FRENCH,
	POLISH
};
typedef enum langues langues;


void choisir_langue(langues* langue);



#endif
