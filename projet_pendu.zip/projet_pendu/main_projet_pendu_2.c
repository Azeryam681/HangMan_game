#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <wchar.h>
#include <locale.h>



#include "fonction_fichier_mots.h"
#include "fonction_affichage.h"
#include "fonction_langue.h"
#include "unistd.h"






int main()
{
	
	setlocale(LC_ALL, "");
	FILE* fichier;
	int nombre_essai, i, decouvert, nombre_tour, taille_mot, fermeture, continuer;
	long nbr_ligne, position_mot;

	wchar_t mot_aleatoire[100];
	wchar_t* proposition = (wchar_t*)malloc(sizeof(wchar_t) * (20));
	
	//wchar_t alphabet[27] = L"##########################";  // l'alphabet des lettres qui ont été utilisés 	initialement l'alphabet contient 26 fois #
	wchar_t alphabet[27];
	wchar_t lettre;
	
	langues langue;
	
	continuer = 1;
	
	while(continuer)
	{
		alphabet_vide(alphabet);
		
		choisir_langue(&langue);
		
		position_mot = 0;
		i = 0;
		decouvert = 0;
		nombre_tour = 0; // nombre de tour qui ont été joué par le joueur
		
		demander_essai(&nombre_essai);
		
		
		
		if (langue == FRENCH)
			//fichier = ouvrir_fichier("/home/azeryam/Documents/c_language/projet_pendu/listes_mots/mots_francais.txt");
			fichier = ouvrir_fichier("listes_mots/mots_francais.txt");
		else if(langue == ENGLISH)
			fichier = ouvrir_fichier("listes_mots/mots_anglais.txt");	
		
		else if(langue == POLISH)
			fichier = ouvrir_fichier("listes_mots/mots_polonais.txt");	
		nbr_ligne = compter_ligne(fichier);
		
		
		
		choisir_mot(fichier, mot_aleatoire, &taille_mot, &position_mot);
		
		
		wprintf(L"la longueur du mot : %d\n",taille_mot);
		wprintf(L"le mot  choisi aléatoirement :%ls\n",mot_aleatoire);
		wprintf(L"le mot est en position : %d\n",position_mot);
		
		initialiser_mot(taille_mot, proposition);
		non_accentue(mot_aleatoire); // on transforme le mot en mot non accentué
		
		
		
		wprintf(L"alphabet :%ls\n",alphabet);
		
		while((i < nombre_essai) && (!decouvert))
		{
					// Dérouler d'un essai
			/*
			un essai comprend :
			-- l'affichage du numéro d'essai
			-- l'affichage du nombre d'essai restant
			-- l'affichage des lettres qui ont été utilisés
			-- l'affichage du mot avec ses lettres découvertes
			
			-- la saisi d'une lettre 
			-- si la lettre saisie est 0 saisi d'un mot
			*/
			
			/*
			fflush(stdout);
			
			execl("/bin/clear", "clear", NULL);
			
			fflush(stdout);
			*/
			
			nombre_tour++ ;	
			
			wprintf(L"####################### ESSAIS: %d #######################\n",nombre_tour );
			
			wprintf(L"\n\n");
			wprintf(L"il vous reste %d essais\n",nombre_essai - i);
			wprintf(L"alphabet des lettres utilisés :%ls\n",alphabet);
			
			affichage_mot(mot_aleatoire, alphabet);
			
			wprintf(L"Saisir une lettre :\n");
			wscanf(L"%c",&lettre);
			
			wprintf(L"La proposition : %ls\n",proposition);
			
			getwchar();
			
			if(lettre == (L'0'))
			{
				wprintf(L"la lettre saisi était 0\n");
				proposition = ecrire_mot(proposition);
				wprintf(L"\nle mot que vous avez écrit : %ls\n",proposition);
				i++ ; 
			}
			
			
			else
			{
				if (appartient_mot(mot_aleatoire, lettre) == 1)
					wprintf(L"la lettre : %c est dans le mot\n", lettre);
				else
				{
					wprintf(L"la lettre : %c n' est pas dans le mot\n", lettre);
					i++ ;
				}
			}	
			
					// fin dérouler de l'essai
					
					// traitement des données saisis
			
			ajouter_lettre(alphabet, lettre); // ajouter la lettre dans l'alphabet des lettres découverte si cette lettre était 0 rien ne sera ajouté
			
			
			affichage_mot(mot_aleatoire, alphabet); 
			
					// fin traitement des données saisis
					
					// arrêt de la boucle si le mot est découvert
			decouvert = est_correct(mot_aleatoire, proposition, alphabet);
			if (decouvert)
				wprintf(L"Vous avez trouvé le mot, bravo ");
			
			
			
			wprintf(L"########################################################\n\n\n\n");
			
			
		}

		
		wprintf(L"le mot  choisi aléatoirement :%ls\n",mot_aleatoire);
		
		
		
		fermeture = fermer_fichier(fichier);
		
		wprintf(L"fermeture du fichier : %d\n",fermeture);
		
		// Demander au joueur s'il veut continuer, terminer le programme s'il ne le souhaite pas
		wprintf(L"Souhaitez vous rejouer une partie ? 1 pour oui, 0 pour non\n");
		wscanf(L"%d",&continuer);
		getwchar();
		
	}

}

